# Cutty Beats

A small Android music player that plays songs online from YouTube Music, with no login.

The online sound system comes from the Square project:

- `NewPipeDownloader.kt` + NewPipeExtractor: search, and direct audio addresses
- `ChunkedDataSource.kt`: reads YouTube streams in pieces so playback does not stall
- `PlaybackService.kt`: Media3/ExoPlayer in a background service, with notification and lock-screen controls

Screens: Search (frosted-glass home with Recently Played and trending songs; slide a finger along the bottom bar to switch tabs), Liked, Queue, a mini player and a full Now Playing screen. While a song plays, the top of Now Playing has Lyrics (timed, from LRCLIB) and Effects (presets, bass boost, 3D surround, loudness, speed). Dark theme, pink accent (#FF4FA3).

Under the lyrics, a translation (10 languages: Hindi, English, Bengali, Tamil, Telugu, Marathi, Gujarati, Punjabi, Urdu, Kannada) is shown for every line; pick the language with the three dots (⋮) in the lyrics panel. Songs start fast: audio addresses are looked up ahead of time for the top results and the next song.

**YouTube tab** (4th tab in the bottom bar): search any YouTube video, tap it and it plays inside the app, with no ads. The picture is chosen for you (720p, or the best below it) and can be changed from the quality button; the full-screen button turns the phone sideways. The song now playing can be opened as a video with the video button at the top of Now Playing. The music stops while a video plays, and the picture stops when you leave the tab or the app (music keeps playing in the background).

**Instagram tab** (5th tab): opens Instagram's login page; log in once and it stays logged in. The Home and Reels buttons at the top open the feed and the Reels. Instagram's own ads show; reels cannot be downloaded or played in the background.

**Downloads**: the arrow next to the heart in Now Playing saves the song on the phone (inside the app). Saved songs are listed under "Downloaded" in the Liked tab, play with no internet, and can be deleted there.

Tap an artist name (in a song row or on Now Playing) to open the artist page: photo, subscribers, description and the songs counted on their channel.

## Build the APK

GitHub: upload everything (including the `.github` folder) to a repository, open
Actions, run **Build APK**, then download `cutty-beats-apk` from the finished run.

Android Studio: open the folder and press Run, or run `./gradlew :app:assembleDebug`.

## Licence

GPL-3.0 (see LICENSE), because NewPipeExtractor is GPL-3.0.
