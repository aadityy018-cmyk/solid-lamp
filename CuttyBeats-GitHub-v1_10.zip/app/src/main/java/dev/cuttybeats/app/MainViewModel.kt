package dev.cuttybeats.app

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id)
    .setUri("${PlaybackService.SCHEME}://yt/$id")
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setArtworkUri(thumb?.let { Uri.parse(it) })
            .setExtras(Bundle().apply { putString(ARTIST_URL, artistUrl) })
            .build(),
    )
    .build()

fun MediaItem.toSong(): Song = Song(
    id = mediaId,
    title = mediaMetadata.title?.toString().orEmpty(),
    artist = mediaMetadata.artist?.toString().orEmpty(),
    thumb = mediaMetadata.artworkUri?.toString(),
    durationSec = 0,
    artistUrl = mediaMetadata.extras?.getString(ARTIST_URL),
)

const val ARTIST_URL = "artistUrl"

class MainViewModel(app: Application) : AndroidViewModel(app) {

    // Search
    var query by mutableStateOf("")
    var results by mutableStateOf<List<Song>>(emptyList())
    var searching by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    // Songs shown on the home screen before anything is searched
    var home by mutableStateOf<List<Song>>(emptyList())
        private set
    var homeLoading by mutableStateOf(false)
        private set

    // Recently played, newest first
    var recent by mutableStateOf<List<Song>>(emptyList())
        private set
    private var lastRecentId: String? = null

    // Artist page
    var artistOpen by mutableStateOf(false)
        private set
    var artist by mutableStateOf<ArtistData?>(null)
        private set
    var artistLoading by mutableStateOf(false)
        private set

    // YouTube tab
    val video = VideoHolder(app, viewModelScope)
    var videoQuery by mutableStateOf("")
    var videos by mutableStateOf<List<Video>>(emptyList())
        private set
    var videosLoading by mutableStateOf(false)
        private set
    var videoMessage by mutableStateOf<String?>(null)
        private set
    /** True while [videos] is the starting feed and not a search. */
    var videoIsHome by mutableStateOf(true)
        private set

    // Library
    var liked by mutableStateOf<List<Song>>(emptyList())
        private set

    // Songs saved on the phone, and the progress (0..1) of those being saved
    var downloaded by mutableStateOf<List<Song>>(emptyList())
        private set
    var downloading by mutableStateOf<Map<String, Float>>(emptyMap())
        private set

    // Player state, mirrored from the MediaController
    var controller by mutableStateOf<MediaController?>(null)
        private set
    var current by mutableStateOf<MediaItem?>(null)
        private set
    var currentIndex by mutableIntStateOf(0)
        private set
    var queue by mutableStateOf<List<MediaItem>>(emptyList())
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set

    // Lyrics
    var lyrics by mutableStateOf<Lyrics?>(null)
        private set
    var lyricsLoading by mutableStateOf(false)
        private set
    private var lyricsFor: String? = null

    // Lyrics translation shown under each line
    var lyricLang by mutableStateOf("hi")
        private set
    var translation by mutableStateOf<List<String>?>(null)
        private set
    var translating by mutableStateOf(false)
        private set
    private var translateJob: kotlinx.coroutines.Job? = null

    // Effects, kept on the phone and sent to the player service
    var fxPreset by mutableIntStateOf(0)
        private set
    var fxBass by mutableIntStateOf(0)
        private set
    var fxVirt by mutableIntStateOf(0)
        private set
    var fxLoud by mutableIntStateOf(0)
        private set
    var speed by mutableFloatStateOf(1f)
        private set

    private val prefs = app.getSharedPreferences("cutty", 0)

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
        override fun onPlayerError(error: PlaybackException) = toast("Could not play this song. Try another one.")
    }

    init {
        loadLiked()
        loadDownloaded()
        loadRecent()
        lyricLang = prefs.getString("lyric_lang", "hi") ?: "hi"
        viewModelScope.launch(Dispatchers.IO) { runCatching { YouTubeRepo.warmUp() } }
        fxPreset = prefs.getInt("fx_preset", 0)
        fxBass = prefs.getInt("fx_bass", 0)
        fxVirt = prefs.getInt("fx_virt", 0)
        fxLoud = prefs.getInt("fx_loud", 0)
        speed = prefs.getFloat("speed", 1f)

        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching { future.get() }.onSuccess { c ->
                c.addListener(listener)
                controller = c
                sync(c)
                sendEffect(EffectKeys.PRESET, fxPreset)
                sendEffect(EffectKeys.BASS, fxBass)
                sendEffect(EffectKeys.VIRT, fxVirt)
                sendEffect(EffectKeys.LOUD, fxLoud)
                c.setPlaybackSpeed(speed)
            }
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                controller?.let {
                    positionMs = it.currentPosition
                    durationMs = it.duration.coerceAtLeast(0L)
                }
                delay(400)
            }
        }
        loadHome()
    }

    private fun toast(text: String) {
        Toast.makeText(getApplication(), text, Toast.LENGTH_SHORT).show()
    }

    private fun sync(p: Player) {
        // Music and video never play together.
        if (p.isPlaying) video.pause()
        current = p.currentMediaItem
        p.currentMediaItem?.let { loadLyrics(it) }
        prefetchNext(p)
        if (p.isPlaying) p.currentMediaItem?.let { noteRecent(it) }
        currentIndex = p.currentMediaItemIndex
        queue = List(p.mediaItemCount) { p.getMediaItemAt(it) }
        isPlaying = p.isPlaying
        buffering = p.playbackState == Player.STATE_BUFFERING
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
    }

    // --- Home and search ---------------------------------------------------

    /** Fills the home screen with popular songs. Needs the internet. */
    fun loadHome() {
        if (homeLoading) return
        viewModelScope.launch {
            homeLoading = true
            val found = withContext(Dispatchers.IO) {
                listOf("latest hindi songs 2026", "bollywood top hits", "punjabi hit songs")
                    .flatMap { q -> runCatching { YouTubeRepo.search(q) }.getOrDefault(emptyList()) }
                    .distinctBy { it.id }
            }
            home = found
            homeLoading = false
            found.take(3).forEach { YouTubeRepo.prefetch(it.id) }
        }
    }

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) {
            results = emptyList()
            message = null
            return
        }
        viewModelScope.launch {
            searching = true
            message = null
            try {
                results = withContext(Dispatchers.IO) { YouTubeRepo.search(q) }
                results.take(3).forEach { YouTubeRepo.prefetch(it.id) }
                if (results.isEmpty()) message = "Nothing found for \"$q\"."
            } catch (e: Exception) {
                results = emptyList()
                message = "Search failed. Check your internet and try again."
            } finally {
                searching = false
            }
        }
    }

    // --- YouTube videos ----------------------------------------------------

    /** The starting feed of the YouTube tab. Needs the internet. */
    fun loadVideoHome() {
        if (videosLoading) return
        viewModelScope.launch {
            videosLoading = true
            videoMessage = null
            val found = withContext(Dispatchers.IO) {
                listOf("trending videos today", "new hindi songs official video")
                    .flatMap { q -> runCatching { YouTubeRepo.searchVideos(q) }.getOrDefault(emptyList()) }
                    .distinctBy { it.id }
            }
            videos = found
            videoIsHome = true
            if (found.isEmpty()) videoMessage = "Could not load videos. Check your internet, then tap here to retry."
            videosLoading = false
        }
    }

    fun searchVideos() {
        val q = videoQuery.trim()
        if (q.isEmpty()) {
            loadVideoHome()
            return
        }
        viewModelScope.launch {
            videosLoading = true
            videoMessage = null
            try {
                videos = withContext(Dispatchers.IO) { YouTubeRepo.searchVideos(q) }
                videoIsHome = false
                if (videos.isEmpty()) videoMessage = "Nothing found for \"$q\"."
            } catch (e: Exception) {
                videos = emptyList()
                videoMessage = "Search failed. Check your internet and try again."
            } finally {
                videosLoading = false
            }
        }
    }

    /** Plays [v] in the YouTube tab, and stops the music first. */
    fun watch(v: Video) {
        controller?.pause()
        video.play(v)
    }

    /** The song now playing, as a video. */
    fun watchCurrent() {
        val item = current ?: return
        val s = item.toSong()
        watch(Video(id = s.id, title = s.title, channel = s.artist, thumb = s.thumb, durationSec = 0))
    }

    // --- Playback ----------------------------------------------------------

    fun play(songs: List<Song>, index: Int) {
        val c = controller ?: return
        songs.getOrNull(index)?.let { YouTubeRepo.prefetch(it.id) }
        songs.getOrNull(index + 1)?.let { YouTubeRepo.prefetch(it.id) }
        c.setMediaItems(songs.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) play(listOf(song), 0) else c.addMediaItem(song.toMediaItem())
        toast("Added to queue")
    }

    fun playQueueItem(index: Int) {
        controller?.run {
            seekToDefaultPosition(index)
            play()
        }
    }

    fun togglePlay() {
        controller?.run { if (isPlaying) pause() else play() }
    }

    fun next() { controller?.seekToNextMediaItem() }

    fun previous() {
        controller?.run { if (currentPosition > 3000) seekTo(0) else seekToPreviousMediaItem() }
    }

    fun seekTo(ms: Long) { controller?.seekTo(ms) }

    fun toggleShuffle() {
        controller?.run { shuffleModeEnabled = !shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.run {
            repeatMode = when (repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    // --- Artist ------------------------------------------------------------

    /** Opens the artist page: who made the song and the songs on their channel. */
    fun openArtist(name: String, channelUrl: String?) {
        if (name.isBlank() && channelUrl.isNullOrBlank()) return
        artistOpen = true
        artist = null
        artistLoading = true
        viewModelScope.launch {
            val found = withContext(Dispatchers.IO) {
                runCatching { YouTubeRepo.artist(name, channelUrl) }.getOrNull()
            }
            artist = found
            artistLoading = false
        }
    }

    fun closeArtist() {
        artistOpen = false
    }

    // --- Lyrics ------------------------------------------------------------

    fun loadLyrics(item: MediaItem) {
        if (lyricsFor == item.mediaId) return
        val id = item.mediaId
        lyricsFor = id
        lyrics = null
        lyricsLoading = true
        val title = item.mediaMetadata.title?.toString().orEmpty()
        val artist = item.mediaMetadata.artist?.toString().orEmpty()
        viewModelScope.launch {
            val found = withContext(Dispatchers.IO) {
                runCatching { LyricsRepo.fetch(title, artist) }.getOrNull()
            }
            if (lyricsFor == id) {
                lyrics = found
                lyricsLoading = false
                translate()
            }
        }
    }

    /** Lines of the lyrics, in order, as shown on screen. */
    fun lyricLines(): List<String> {
        val l = lyrics ?: return emptyList()
        return if (l.synced.isNotEmpty()) l.synced.map { it.text } else l.plain.orEmpty().lines()
    }

    fun setLyricLang(code: String) {
        lyricLang = code
        prefs.edit().putString("lyric_lang", code).apply()
        translate()
    }

    private fun translate() {
        translateJob?.cancel()
        translation = null
        val id = lyricsFor ?: return
        val lang = lyricLang
        val lines = lyricLines()
        if (lang.isEmpty() || lines.isEmpty()) { translating = false; return }
        translating = true
        translateJob = viewModelScope.launch {
            val out = withContext(Dispatchers.IO) {
                runCatching { TranslateRepo.translate(id, lines, lang) }.getOrNull()
            }
            if (lyricsFor == id && lyricLang == lang) {
                translation = out
                translating = false
            }
        }
    }

    private var prefetchedFor: String? = null
    private fun prefetchNext(p: Player) {
        val next = p.currentMediaItemIndex + 1
        if (next >= p.mediaItemCount) return
        val id = p.getMediaItemAt(next).mediaId
        if (prefetchedFor == id) return
        prefetchedFor = id
        YouTubeRepo.prefetch(id)
    }

    // --- Effects -----------------------------------------------------------

    private fun sendEffect(type: String, value: Int) {
        val extras = Bundle().apply {
            putString(EffectKeys.TYPE, type)
            putInt(EffectKeys.VALUE, value)
        }
        controller?.sendCustomCommand(SessionCommand(EffectKeys.ACTION, Bundle.EMPTY), extras)
    }

    fun setEffect(type: String, value: Int) {
        when (type) {
            EffectKeys.PRESET -> { fxPreset = value; prefs.edit().putInt("fx_preset", value).apply() }
            EffectKeys.BASS -> { fxBass = value; prefs.edit().putInt("fx_bass", value).apply() }
            EffectKeys.VIRT -> { fxVirt = value; prefs.edit().putInt("fx_virt", value).apply() }
            EffectKeys.LOUD -> { fxLoud = value; prefs.edit().putInt("fx_loud", value).apply() }
        }
        sendEffect(type, value)
    }

    fun setSpeed(value: Float) {
        speed = value
        prefs.edit().putFloat("speed", value).apply()
        controller?.setPlaybackSpeed(value)
    }

    // --- Liked songs, kept on the phone -------------------------------------

    fun isLiked(id: String) = liked.any { it.id == id }

    fun toggleLike(song: Song) {
        liked = if (isLiked(song.id)) liked.filterNot { it.id == song.id } else listOf(song) + liked
        saveLiked()
    }

    private fun noteRecent(item: MediaItem) {
        if (item.mediaId == lastRecentId) return
        lastRecentId = item.mediaId
        val song = item.toSong()
        recent = (listOf(song) + recent.filterNot { it.id == song.id }).take(12)
        val arr = JSONArray()
        recent.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("title", it.title).put("artist", it.artist)
                    .put("thumb", it.thumb ?: "").put("d", it.durationSec)
                    .put("au", it.artistUrl ?: ""),
            )
        }
        prefs.edit().putString("recent", arr.toString()).apply()
    }

    private fun loadRecent() {
        val raw = prefs.getString("recent", null) ?: return
        recent = runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) {
                val o = arr.getJSONObject(it)
                Song(
                    o.getString("id"), o.getString("title"), o.getString("artist"),
                    o.optString("thumb").ifEmpty { null }, o.optLong("d"),
                    o.optString("au").ifEmpty { null },
                )
            }
        }.getOrDefault(emptyList())
    }

    fun isDownloaded(id: String) = downloaded.any { it.id == id }

    fun download(song: Song) {
        if (isDownloaded(song.id)) {
            toast("Already downloaded")
            return
        }
        if (downloading.containsKey(song.id)) return
        downloading = downloading + (song.id to 0f)
        toast("Downloading…")
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                var done = false
                // Once more with a fresh address if the first one had run out.
                repeat(2) {
                    if (!done) {
                        try {
                            SongFiles.download(getApplication<Application>(), song.id) { p ->
                                viewModelScope.launch { downloading = downloading + (song.id to p) }
                            }
                            done = true
                        } catch (e: Exception) {
                            YouTubeRepo.forget(song.id)
                        }
                    }
                }
                done
            }
            downloading = downloading - song.id
            if (ok) {
                downloaded = listOf(song) + downloaded
                saveDownloaded()
                toast("Downloaded: ${song.title}")
            } else {
                toast("Download failed. Check your internet and try again.")
            }
        }
    }

    fun deleteDownload(song: Song) {
        SongFiles.file(getApplication<Application>(), song.id).delete()
        downloaded = downloaded.filter { it.id != song.id }
        saveDownloaded()
    }

    private fun loadDownloaded() {
        val raw = prefs.getString("downloaded", null) ?: return
        downloaded = runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) {
                val o = arr.getJSONObject(it)
                Song(
                    o.getString("id"), o.getString("title"), o.getString("artist"),
                    o.optString("thumb").ifEmpty { null }, o.optLong("d"),
                    o.optString("au").ifEmpty { null },
                )
            }
        }.getOrDefault(emptyList())
            .filter { SongFiles.file(getApplication<Application>(), it.id).exists() }
    }

    private fun saveDownloaded() {
        val arr = JSONArray()
        downloaded.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("title", it.title).put("artist", it.artist)
                    .put("thumb", it.thumb ?: "").put("d", it.durationSec)
                    .put("au", it.artistUrl ?: ""),
            )
        }
        prefs.edit().putString("downloaded", arr.toString()).apply()
    }

    fun clearLiked() {
        liked = emptyList()
        saveLiked()
    }

    private fun loadLiked() {
        val raw = prefs.getString("liked", null) ?: return
        liked = runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) {
                val o = arr.getJSONObject(it)
                Song(
                    o.getString("id"), o.getString("title"), o.getString("artist"),
                    o.optString("thumb").ifEmpty { null }, o.optLong("d"),
                    o.optString("au").ifEmpty { null },
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun saveLiked() {
        val arr = JSONArray()
        liked.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("title", it.title).put("artist", it.artist)
                    .put("thumb", it.thumb ?: "").put("d", it.durationSec)
                    .put("au", it.artistUrl ?: ""),
            )
        }
        prefs.edit().putString("liked", arr.toString()).apply()
    }

    override fun onCleared() {
        video.release()
        controller?.run {
            removeListener(listener)
            release()
        }
        super.onCleared()
    }
}
