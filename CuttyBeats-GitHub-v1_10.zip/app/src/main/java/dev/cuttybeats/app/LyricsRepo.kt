package dev.cuttybeats.app

import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

data class LyricLine(val timeMs: Long, val text: String)

/** [synced] is empty when the song only has plain lyrics. */
data class Lyrics(val synced: List<LyricLine>, val plain: String?)

/** Finds lyrics (timed where possible) from the free LRCLIB service. Blocking. */
object LyricsRepo {
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val TIMESTAMP = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    fun fetch(title: String, artist: String): Lyrics? {
        val t = cleanTitle(title)
        val a = cleanArtist(artist)
        for (q in listOf("$t $a".trim(), t)) {
            if (q.isBlank()) continue
            search(q)?.let { return it }
        }
        return null
    }

    private fun search(q: String): Lyrics? {
        val url = HttpUrl.Builder()
            .scheme("https").host("lrclib.net")
            .addPathSegments("api/search")
            .addQueryParameter("q", q)
            .build()
        val request = Request.Builder().url(url).header("User-Agent", "CuttyBeats/1.1 (Android)").build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val body = response.body?.string() ?: return null
            val arr = JSONArray(body)
            var plainOnly: Lyrics? = null
            for (i in 0 until minOf(arr.length(), 8)) {
                val o = arr.getJSONObject(i)
                val synced = o.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                val plain = o.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
                if (synced != null) {
                    val lines = parse(synced)
                    if (lines.isNotEmpty()) return Lyrics(lines, plain)
                }
                if (plain != null && plainOnly == null) plainOnly = Lyrics(emptyList(), plain)
            }
            return plainOnly
        }
    }

    private fun parse(text: String): List<LyricLine> {
        val out = mutableListOf<LyricLine>()
        for (line in text.lines()) {
            val stamps = TIMESTAMP.findAll(line).toList()
            if (stamps.isEmpty()) continue
            val words = line.substring(stamps.last().range.last + 1).trim()
            for (m in stamps) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.toLong()
                }
                out += LyricLine(min * 60_000 + sec * 1000 + ms, words)
            }
        }
        return out.sortedBy { it.timeMs }
    }

    private fun cleanTitle(t: String): String = t
        .replace(Regex("\\(.*?\\)|\\[.*?]"), " ")
        .replace(Regex("(?i)\\b(official|video|audio|lyrics?|lyrical|full song|hd|4k|song)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun cleanArtist(a: String): String = a
        .replace(Regex("(?i)\\s*-\\s*topic$"), "")
        .replace(Regex("(?i)vevo$"), "")
        .trim()
}
