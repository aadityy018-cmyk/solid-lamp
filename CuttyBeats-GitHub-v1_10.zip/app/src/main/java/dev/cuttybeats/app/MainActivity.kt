package dev.cuttybeats.app

import android.Manifest
import android.app.Activity
import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlin.math.roundToInt

// --- Look: soft purple-blue-pink backdrop and frosted glass panels -----------

private val Ink = Color.White
private val Dim = Color.White.copy(alpha = 0.72f)
private val Lilac = Color(0xFFE9B6FF)
private val Wave = Color(0xFFC084FC)
private val Grad = Brush.linearGradient(listOf(Color(0xFF9333EA), Color(0xFFC026D3)))

private val Scheme: ColorScheme = darkColorScheme(
    primary = Color(0xFFA855F7),
    onPrimary = Color.White,
    background = Color(0xFF2B2278),
    onBackground = Ink,
    surface = Color(0xFF2B2278),
    onSurface = Ink,
)

/** The blurry purple, blue and pink backdrop. */
private fun Modifier.neon(): Modifier = drawBehind {
    val w = size.width
    val h = size.height
    drawRect(Brush.verticalGradient(listOf(Color(0xFF2B2278), Color(0xFF3A2A8E), Color(0xFF2A2272))))
    fun blob(color: Color, alpha: Float, x: Float, y: Float, r: Float) {
        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = alpha), Color.Transparent), Offset(x, y), r),
            radius = r, center = Offset(x, y),
        )
    }
    blob(Color(0xFF3B6BFF), 0.55f, w * 0.95f, h * 0.05f, w * 0.90f)
    blob(Color(0xFFB45CF0), 0.55f, w * 0.45f, h * 0.40f, w * 0.95f)
    blob(Color(0xFFFF4FA8), 0.60f, w * 0.05f, h * 0.98f, w * 1.00f)
    blob(Color(0xFFFF6FB5), 0.40f, w * 1.00f, h * 0.78f, w * 0.80f)
}

/** Frosted glass: a pale see-through fill and a thin bright edge. */
private fun Modifier.glass(radius: Dp = 24.dp, strong: Boolean = false): Modifier = drawBehind {
    val corner = CornerRadius(radius.toPx())
    drawRoundRect(
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = if (strong) 0.30f else 0.20f),
                Color.White.copy(alpha = if (strong) 0.14f else 0.08f),
            ),
        ),
        cornerRadius = corner,
    )
    drawRoundRect(
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.65f), Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.35f)),
        ),
        cornerRadius = corner, style = Stroke(1.dp.toPx()),
    )
}

/** Stops touches reaching whatever is underneath a full-screen layer. */
private fun Modifier.blockTouches(): Modifier = pointerInput(Unit) { detectTapGestures { } }

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = Scheme) {
                val askNotifications = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission(),
                ) { }
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                CuttyApp(vm)
            }
        }
    }

    /** The picture stops when the app leaves the screen; the music goes on. */
    override fun onStop() {
        vm.video.pause()
        super.onStop()
    }
}

private enum class Overlay { NONE, EFFECTS, SETTINGS }

// --- App shell -------------------------------------------------------------

@Composable
fun CuttyApp(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(Overlay.NONE) }

    Box(Modifier.fillMaxSize().neon()) {
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0),
            bottomBar = {
                Column(Modifier.navigationBarsPadding()) {
                    if (vm.current != null) MiniPlayer(vm) { showPlayer = true }
                    GlassNavBar(tab) { tab = it }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> SearchScreen(
                        vm,
                        onEffects = { overlay = Overlay.EFFECTS },
                        onSettings = { overlay = Overlay.SETTINGS },
                    )
                    1 -> LikedScreen(vm)
                    2 -> QueueScreen(vm)
                    3 -> VideoScreen(vm)
                    else -> InstagramScreen()
                }
            }
        }

        AnimatedVisibility(
            visible = overlay != Overlay.NONE,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it },
        ) {
            when (overlay) {
                Overlay.EFFECTS -> EffectsScreen(vm) { overlay = Overlay.NONE }
                Overlay.SETTINGS -> SettingsScreen(vm) { overlay = Overlay.NONE }
                Overlay.NONE -> Unit
            }
        }
        BackHandler(enabled = overlay != Overlay.NONE) { overlay = Overlay.NONE }

        AnimatedVisibility(
            visible = showPlayer,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            NowPlaying(vm, onWatch = { vm.watchCurrent(); tab = 3; showPlayer = false }) { showPlayer = false }
        }
        BackHandler(enabled = showPlayer) { showPlayer = false }

        // Above Now Playing, so opening an artist from there lands on top of it.
        AnimatedVisibility(
            visible = vm.artistOpen,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it },
        ) {
            ArtistScreen(vm) { vm.closeArtist() }
        }
        BackHandler(enabled = vm.artistOpen) { vm.closeArtist() }

        // The picture on the whole screen, above everything.
        if (vm.video.fullscreen) FullscreenVideo(vm)
    }
}

/**
 * The bottom bar. Put a finger on it and slide: the glass highlight follows the
 * finger and the tab under it opens. Lift, and it settles on that tab.
 */
@Composable
private fun GlassNavBar(selected: Int, onSelect: (Int) -> Unit) {
    val tabs = listOf<Pair<String, ImageVector>>(
        "Search" to Icons.Rounded.Search,
        "Liked" to Icons.Rounded.FavoriteBorder,
        "Queue" to Icons.Rounded.QueueMusic,
        "YouTube" to Icons.Rounded.SmartDisplay,
        "Instagram" to Icons.Rounded.PhotoCamera,
    )
    val onSel by rememberUpdatedState(onSelect)
    var widthPx by remember { mutableFloatStateOf(0f) }
    var fingerX by remember { mutableStateOf<Float?>(null) }

    val slot = if (widthPx > 0f) widthPx / tabs.size else 0f
    val target = fingerX?.let { (it - slot / 2).coerceIn(0f, (widthPx - slot).coerceAtLeast(0f)) }
        ?: (selected * slot)
    val offset by animateFloatAsState(
        targetValue = target,
        animationSpec = if (fingerX != null) snap() else spring(stiffness = Spring.StiffnessMediumLow),
        label = "navHighlight",
    )

    Box(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).height(70.dp)
            .glass(32.dp)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(Unit) {
                awaitEachGesture {
                    fun pick(x: Float) {
                        if (widthPx > 0f) {
                            onSel(((x / widthPx) * tabs.size).toInt().coerceIn(0, tabs.size - 1))
                        }
                    }
                    val down = awaitFirstDown()
                    fingerX = down.position.x
                    pick(down.position.x)
                    down.consume()
                    while (true) {
                        val change = awaitPointerEvent().changes.firstOrNull() ?: break
                        if (!change.pressed) break
                        fingerX = change.position.x
                        pick(change.position.x)
                        change.consume()
                    }
                    fingerX = null
                }
            },
    ) {
        if (slot > 0f) {
            Box(
                Modifier.offset { IntOffset(offset.roundToInt(), 0) }
                    .width(with(LocalDensity.current) { slot.toDp() })
                    .fillMaxHeight().padding(7.dp)
                    .glass(26.dp, strong = true),
            ) {
                Box(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp)
                        .width(30.dp).height(3.dp).clip(RoundedCornerShape(50)).background(Lilac),
                )
            }
        }
        Row(Modifier.fillMaxSize()) {
            tabs.forEachIndexed { i, (label, icon) ->
                val active = i == selected
                Column(
                    Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(icon, label, tint = if (active) Ink else Dim, modifier = Modifier.size(26.dp))
                    Text(
                        label, color = if (active) Ink else Dim,
                        fontSize = 13.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                    )
                }
            }
        }
    }
}

@Composable
private fun GlassIconButton(icon: ImageVector, desc: String, selected: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).glass(21.dp, strong = selected).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = if (selected) Lilac else Ink, modifier = Modifier.size(22.dp)) }
}

/** The round purple play / pause button. */
@Composable
private fun PlayDot(size: Dp, playing: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Grad)
            .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            "Play or pause", tint = Color.White, modifier = Modifier.size(size * 0.58f),
        )
    }
}

@Composable
private fun Title(
    text: String,
    subtitle: String? = null,
    leading: @Composable RowScope.() -> Unit = {},
    trailing: @Composable RowScope.() -> Unit = {},
) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        leading()
        Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
            Text(text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Ink, maxLines = 1)
            if (subtitle != null) {
                Text(
                    subtitle, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    color = Lilac, letterSpacing = 0.4.sp,
                )
            }
        }
        trailing()
    }
}

@Composable
private fun SectionHeader(text: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = Ink)
    }
}

@Composable
private fun BackRow(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlassIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onClick = onBack)
        Spacer(Modifier.width(14.dp))
        Text(title, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

// --- Screens ---------------------------------------------------------------

@Composable
private fun SearchScreen(vm: MainViewModel, onEffects: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Title(
            "Cutty Beats", subtitle = "Aniket Yadav",
            leading = { GlassIconButton(Icons.Rounded.Apps, "Settings", onClick = onSettings) },
            trailing = { GlassIconButton(Icons.Rounded.GraphicEq, "Effects", onClick = onEffects) },
        )
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass(30.dp)) {
            OutlinedTextField(
                value = vm.query,
                onValueChange = {
                    vm.query = it
                    if (it.isBlank()) {
                        vm.results = emptyList()
                        vm.message = null
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Songs, artists…", color = Dim) },
                leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Ink) },
                singleLine = true,
                shape = RoundedCornerShape(30.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    cursorColor = Lilac,
                    focusedTextColor = Ink,
                    unfocusedTextColor = Ink,
                ),
            )
        }
        Spacer(Modifier.height(6.dp))
        when {
            vm.searching -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                CircularProgressIndicator(color = Lilac)
            }
            vm.results.isNotEmpty() -> LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                itemsIndexed(vm.results, key = { _, s -> s.id }) { i, song ->
                    SongRow(vm, song, onClick = { vm.play(vm.results, i) })
                }
            }
            vm.message != null && vm.query.isNotBlank() -> Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Text(vm.message.orEmpty(), color = Dim, textAlign = TextAlign.Center)
            }
            vm.homeLoading && vm.home.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                CircularProgressIndicator(color = Lilac)
            }
            vm.home.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Text(
                    "Could not load songs. Check your internet, then tap here to retry.",
                    color = Dim, textAlign = TextAlign.Center,
                    modifier = Modifier.clickable { vm.loadHome() },
                )
            }
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                if (vm.recent.isNotEmpty()) {
                    item { SectionHeader("Recently Played") }
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            itemsIndexed(vm.recent, key = { _, s -> s.id }) { i, song ->
                                RecentCard(song) { vm.play(vm.recent, i) }
                            }
                        }
                    }
                }
                item { SectionHeader("Trending songs") }
                itemsIndexed(vm.home, key = { _, s -> s.id }) { i, song ->
                    SongRow(vm, song, onClick = { vm.play(vm.home, i) })
                }
            }
        }
    }
}

@Composable
private fun RecentCard(song: Song, onClick: () -> Unit) {
    Column(Modifier.width(104.dp).clickable(onClick = onClick)) {
        val shape = RoundedCornerShape(22.dp)
        Box(
            Modifier.size(104.dp).clip(shape).background(Color.White.copy(alpha = 0.10f))
                .border(1.dp, Color.White.copy(alpha = 0.5f), shape),
            contentAlignment = Alignment.Center,
        ) {
            if (song.thumb != null) {
                AsyncImage(song.thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Icon(Icons.Rounded.LibraryMusic, null, tint = Dim)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            song.title, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
    }
}

// --- Instagram tab ---------------------------------------------------------

/** Instagram's website inside the app: login page first, then feed and Reels. The login is kept. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun InstagramScreen() {
    var web by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    BackHandler(enabled = canGoBack) { web?.goBack() }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val watcher = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) web?.onPause()
            if (event == Lifecycle.Event.ON_START) web?.onResume()
        }
        owner.lifecycle.addObserver(watcher)
        onDispose { owner.lifecycle.removeObserver(watcher) }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Instagram", Modifier.weight(1f), color = Ink, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        GlassIconButton(Icons.Rounded.Home, "Home") { web?.loadUrl("https://www.instagram.com/") }
        Spacer(Modifier.width(8.dp))
        GlassIconButton(Icons.Rounded.SmartDisplay, "Reels") { web?.loadUrl("https://www.instagram.com/reels/") }
    }
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                // Look like a normal phone browser, not an embedded view.
                settings.userAgentString = settings.userAgentString.replace("; wv", "")
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                webViewClient = object : WebViewClient() {
                    override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                        canGoBack = view.canGoBack()
                    }
                }
                // Opens the login page; once logged in, Instagram goes straight to the feed.
                loadUrl("https://www.instagram.com/accounts/login/")
                web = this
            }
        },
        onRelease = { it.destroy(); web = null },
        modifier = Modifier.fillMaxWidth().weight(1f),
    )
    }
}

// --- YouTube tab -----------------------------------------------------------

@Composable
private fun VideoScreen(vm: MainViewModel) {
    val hold = vm.video
    LaunchedEffect(Unit) { if (vm.videos.isEmpty()) vm.loadVideoHome() }
    // Leaving the tab stops the picture.
    DisposableEffect(Unit) { onDispose { hold.pause() } }

    Column(Modifier.fillMaxSize()) {
        Title("YouTube", subtitle = "Watch without ads")
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass(30.dp)) {
            OutlinedTextField(
                value = vm.videoQuery,
                onValueChange = { vm.videoQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search YouTube…", color = Dim) },
                leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Ink) },
                singleLine = true,
                shape = RoundedCornerShape(30.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.searchVideos() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    cursorColor = Lilac,
                    focusedTextColor = Ink,
                    unfocusedTextColor = Ink,
                ),
            )
        }
        Spacer(Modifier.height(10.dp))

        val playing = hold.video
        if (playing != null) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(20.dp)).background(Color.Black),
                    contentAlignment = Alignment.Center,
                ) {
                    // While full screen, the picture is over there.
                    if (!hold.fullscreen) VideoSurface(hold, Modifier.fillMaxSize())
                    if (hold.loading || hold.buffering) {
                        CircularProgressIndicator(color = Lilac)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            playing.title, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                            maxLines = 2, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            playing.channel, color = Lilac, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (hold.qualities.size > 1) {
                        var menu by remember { mutableStateOf(false) }
                        Box {
                            Text(
                                "${hold.quality?.label.orEmpty()} ▾", color = Ink, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp).clickable { menu = true }
                                    .glass(16.dp).padding(horizontal = 12.dp, vertical = 8.dp),
                            )
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                hold.qualities.forEach { q ->
                                    DropdownMenuItem(
                                        text = { Text(q.label, color = if (q == hold.quality) Lilac else Ink) },
                                        trailingIcon = {
                                            if (q == hold.quality) Icon(Icons.Rounded.Check, null, tint = Lilac)
                                        },
                                        onClick = { hold.setQuality(q); menu = false },
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    GlassIconButton(Icons.Rounded.Fullscreen, "Full screen") { hold.fullscreen = true }
                }
            }
            SectionHeader(if (vm.videoIsHome) "Trending" else "Results")
        }

        when {
            vm.videosLoading && vm.videos.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                CircularProgressIndicator(color = Lilac)
            }
            vm.videos.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Text(
                    vm.videoMessage ?: "Search for any video.",
                    color = Dim, textAlign = TextAlign.Center,
                    modifier = Modifier.clickable { vm.searchVideos() },
                )
            }
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                if (playing == null) item { SectionHeader(if (vm.videoIsHome) "Trending" else "Results") }
                itemsIndexed(vm.videos, key = { _, v -> v.id }) { _, v ->
                    VideoRow(v, v.id == playing?.id) { vm.watch(v) }
                }
            }
        }
    }
}

@Composable
private fun VideoRow(v: Video, playing: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val shape = RoundedCornerShape(14.dp)
        Box(
            Modifier.width(144.dp).aspectRatio(16f / 9f).clip(shape)
                .background(Color.White.copy(alpha = 0.10f))
                .border(1.dp, if (playing) Lilac else Color.White.copy(alpha = 0.5f), shape),
            contentAlignment = Alignment.Center,
        ) {
            if (v.thumb != null) {
                AsyncImage(v.thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Icon(Icons.Rounded.SmartDisplay, null, tint = Dim)
            }
            if (v.durationSec > 0) {
                Text(
                    clock(v.durationSec), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp)
                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                v.title, color = Ink, fontSize = 15.sp,
                fontWeight = if (playing) FontWeight.ExtraBold else FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Text(
                listOfNotNull(v.channel.ifBlank { null }, views(v.views)).joinToString(" · "),
                color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** The picture itself, with the player's own play / pause / seek controls. */
@Composable
private fun VideoSurface(hold: VideoHolder, modifier: Modifier) {
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = true
                player = hold.player
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        },
        update = { it.player = hold.player },
        onRelease = { it.player = null },
        modifier = modifier,
    )
}

/** Turns the phone sideways and shows only the picture. Back, or the button, leaves. */
@Composable
private fun FullscreenVideo(vm: MainViewModel) {
    val activity = LocalContext.current as? Activity
    DisposableEffect(Unit) {
        val window = activity?.window
        val bars = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        bars?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        bars?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            bars?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    BackHandler { vm.video.fullscreen = false }
    Box(Modifier.fillMaxSize().background(Color.Black).blockTouches()) {
        VideoSurface(vm.video, Modifier.fillMaxSize())
        if (vm.video.loading || vm.video.buffering) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Lilac)
        }
        Box(Modifier.align(Alignment.TopEnd).padding(16.dp)) {
            GlassIconButton(Icons.Rounded.FullscreenExit, "Exit full screen") { vm.video.fullscreen = false }
        }
    }
}

private fun clock(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

private fun views(n: Long): String? = when {
    n < 0 -> null
    n >= 1_000_000_000 -> "%.1fB views".format(n / 1e9)
    n >= 1_000_000 -> "%.1fM views".format(n / 1e6)
    n >= 1_000 -> "%.1fK views".format(n / 1e3)
    else -> "$n views"
}

/** Save the song on the phone: arrow, then a ring while saving, then a tick. */
@Composable
private fun DownloadButton(vm: MainViewModel, song: Song) {
    val p = vm.downloading[song.id]
    IconButton(onClick = { vm.download(song) }) {
        when {
            p != null && p > 0f -> CircularProgressIndicator(
                progress = { p }, modifier = Modifier.size(22.dp), color = Lilac, strokeWidth = 2.dp,
            )
            p != null -> CircularProgressIndicator(Modifier.size(22.dp), color = Lilac, strokeWidth = 2.dp)
            vm.isDownloaded(song.id) ->
                Icon(Icons.Rounded.DownloadDone, "Downloaded", tint = Lilac, modifier = Modifier.size(26.dp))
            else -> Icon(Icons.Rounded.Download, "Download", tint = Ink, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun LikedScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        Title("Liked")
        if (vm.liked.isEmpty() && vm.downloaded.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Text(
                    "Tap the heart on a song to keep it here. Tap the download arrow in the player to save a song on your phone.",
                    color = Dim, textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                if (vm.liked.isNotEmpty()) item { SectionHeader("Liked") }
                itemsIndexed(vm.liked, key = { _, s -> "l" + s.id }) { i, song ->
                    SongRow(vm, song, onClick = { vm.play(vm.liked, i) })
                }
                if (vm.downloaded.isNotEmpty()) item { SectionHeader("Downloaded") }
                itemsIndexed(vm.downloaded, key = { _, s -> "d" + s.id }) { i, song ->
                    SongRow(
                        vm, song,
                        extra = {
                            IconButton(onClick = { vm.deleteDownload(song) }, modifier = Modifier.size(38.dp)) {
                                Icon(Icons.Rounded.Delete, "Delete download", tint = Ink, modifier = Modifier.size(22.dp))
                            }
                        },
                        onClick = { vm.play(vm.downloaded, i) },
                    )
                }
            }
        }
    }
}

@Composable
private fun QueueScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        Title("Queue")
        if (vm.queue.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Text("Nothing queued yet.", color = Dim)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                itemsIndexed(vm.queue) { i, item ->
                    val playing = i == vm.currentIndex
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
                            .glass(26.dp, strong = playing).clip(RoundedCornerShape(26.dp))
                            .clickable { vm.playQueueItem(i) }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Cover(item.mediaMetadata.artworkUri?.toString(), 52)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                item.mediaMetadata.title?.toString().orEmpty(),
                                color = Ink,
                                fontWeight = if (playing) FontWeight.ExtraBold else FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                item.mediaMetadata.artist?.toString().orEmpty(),
                                color = Dim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        if (playing) Icon(Icons.Rounded.MusicNote, null, tint = Lilac, modifier = Modifier.padding(end = 8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun EffectsScreen(vm: MainViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().neon().blockTouches().statusBarsPadding().navigationBarsPadding()) {
        BackRow("Effects", onBack)
        Box(Modifier.weight(1f).padding(16.dp)) { EffectsPanel(vm) }
    }
}

@Composable
private fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().neon().blockTouches().statusBarsPadding().navigationBarsPadding()) {
        BackRow("Settings", onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.fillMaxWidth().glass(26.dp).padding(18.dp)) {
                Text("Cutty Beats", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text("Made by Aniket Yadav", color = Lilac, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Version 1.4", color = Dim, fontSize = 13.sp)
            }
            GlassButton("Refresh trending songs") { vm.loadHome() }
            GlassButton("Clear liked songs (${vm.liked.size})") { vm.clearLiked() }
        }
    }
}

@Composable
private fun GlassButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().glass(30.dp).clip(RoundedCornerShape(30.dp))
            .clickable(onClick = onClick).padding(vertical = 15.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Ink, fontWeight = FontWeight.SemiBold) }
}

// --- Pieces ----------------------------------------------------------------

@Composable
private fun Cover(url: String?, size: Int) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f))
            .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (url != null) {
            AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Rounded.LibraryMusic, null, tint = Dim)
        }
    }
}

@Composable
private fun SongRow(
    vm: MainViewModel,
    song: Song,
    onArtist: (() -> Unit)? = { vm.openArtist(song.artist, song.artistUrl) },
    extra: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    val playing = vm.current?.mediaId == song.id
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
            .padding(start = 20.dp, end = 14.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(song.thumb, 54)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                color = Ink,
                fontSize = 17.sp,
                fontWeight = if (playing) FontWeight.ExtraBold else FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                song.artist, color = Dim, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = if (onArtist != null) Modifier.clickable(onClick = onArtist) else Modifier,
            )
        }
        IconButton(onClick = { vm.addToQueue(song) }, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Rounded.PlaylistAdd, "Add to queue", tint = Ink, modifier = Modifier.size(24.dp))
        }
        val liked = vm.isLiked(song.id)
        IconButton(onClick = { vm.toggleLike(song) }, modifier = Modifier.size(38.dp)) {
            Icon(
                if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                "Like", tint = if (liked) Lilac else Ink, modifier = Modifier.size(24.dp),
            )
        }
        extra?.invoke()
        Spacer(Modifier.width(6.dp))
        PlayDot(40.dp, playing && vm.isPlaying) { if (playing) vm.togglePlay() else onClick() }
    }
}

@Composable
private fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    val item = vm.current ?: return
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
            .glass(30.dp, strong = true).clip(RoundedCornerShape(30.dp))
            .clickable(onClick = onOpen).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(item.mediaMetadata.artworkUri?.toString(), 46)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.mediaMetadata.title?.toString().orEmpty(),
                color = Ink, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                item.mediaMetadata.artist?.toString().orEmpty(),
                color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        val liked = vm.isLiked(item.mediaId)
        IconButton(onClick = { vm.toggleLike(item.toSong()) }, modifier = Modifier.size(38.dp)) {
            Icon(
                if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                "Like", tint = if (liked) Lilac else Ink, modifier = Modifier.size(24.dp),
            )
        }
        Spacer(Modifier.width(6.dp))
        if (vm.buffering) {
            Box(Modifier.size(40.dp), Alignment.Center) {
                CircularProgressIndicator(Modifier.size(24.dp), color = Lilac, strokeWidth = 2.dp)
            }
        } else {
            PlayDot(40.dp, vm.isPlaying, vm::togglePlay)
        }
    }
}

/** Waves instead of a plain line: tap or slide on it to jump around the song. */
@Composable
private fun WaveSeek(seed: String, positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit) {
    val bars = remember(seed) {
        val rnd = java.util.Random(seed.hashCode().toLong())
        var prev = 0.5f
        FloatArray(54) {
            prev = prev * 0.4f + (0.2f + rnd.nextFloat() * 0.8f) * 0.6f
            prev.coerceIn(0.18f, 1f)
        }
    }
    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = drag ?: if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    Column {
        Canvas(
            Modifier.fillMaxWidth().height(52.dp)
                .pointerInput(durationMs) {
                    detectTapGestures { o ->
                        if (durationMs > 0) onSeek((o.x / size.width * durationMs).toLong())
                    }
                }
                .pointerInput(durationMs) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = {
                            drag?.let { if (durationMs > 0) onSeek((it * durationMs).toLong()) }
                            drag = null
                        },
                        onDragCancel = { drag = null },
                        onHorizontalDrag = { change, _ ->
                            drag = (change.position.x / size.width).coerceIn(0f, 1f)
                            change.consume()
                        },
                    )
                },
        ) {
            val n = bars.size
            val slot = size.width / n
            val barWidth = slot * 0.55f
            bars.forEachIndexed { i, v ->
                val barHeight = size.height * v
                drawRoundRect(
                    color = if ((i + 0.5f) / n <= fraction) Wave else Color.White.copy(alpha = 0.45f),
                    topLeft = Offset(i * slot + (slot - barWidth) / 2, (size.height - barHeight) / 2),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(barWidth / 2),
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(time((fraction * durationMs).toLong()), color = Dim, fontSize = 12.sp)
            Text(time(durationMs), color = Dim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun NowPlaying(vm: MainViewModel, onWatch: () -> Unit, onClose: () -> Unit) {
    val item = vm.current
    var panel by remember { mutableStateOf(Panel.NONE) }
    Column(
        Modifier.fillMaxSize().neon().blockTouches().statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassIconButton(Icons.Rounded.KeyboardArrowDown, "Close", onClick = onClose)
            Text(
                "Now Playing", Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, fontSize = 17.sp,
            )
            GlassIconButton(Icons.Rounded.SmartDisplay, "Watch video", onClick = onWatch)
            Spacer(Modifier.width(8.dp))
            GlassIconButton(Icons.Rounded.Lyrics, "Lyrics", panel == Panel.LYRICS) {
                panel = if (panel == Panel.LYRICS) Panel.NONE else Panel.LYRICS
            }
            Spacer(Modifier.width(8.dp))
            GlassIconButton(Icons.Rounded.Tune, "Effects", panel == Panel.EFFECTS) {
                panel = if (panel == Panel.EFFECTS) Panel.NONE else Panel.EFFECTS
            }
        }
        Box(
            Modifier.fillMaxWidth().weight(1f).padding(vertical = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            when (panel) {
                Panel.LYRICS -> if (item != null) LyricsPanel(vm, item)
                Panel.EFFECTS -> EffectsPanel(vm)
                Panel.NONE -> Box(
                    Modifier.fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true)
                        .glass(400.dp, strong = true).padding(9.dp)
                        .clip(CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    val art = item?.mediaMetadata?.artworkUri?.toString()
                    if (art != null) {
                        AsyncImage(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Icon(Icons.Rounded.LibraryMusic, null, tint = Lilac, modifier = Modifier.size(72.dp))
                    }
                }
            }
        }
        Text(
            item?.mediaMetadata?.title?.toString().orEmpty(),
            color = Ink, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                item?.mediaMetadata?.artist?.toString().orEmpty(),
                color = Lilac, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false).clickable {
                    item?.let {
                        vm.openArtist(
                            it.mediaMetadata.artist?.toString().orEmpty(),
                            it.mediaMetadata.extras?.getString(ARTIST_URL),
                        )
                    }
                },
            )
            if (item != null) {
                val liked = vm.isLiked(item.mediaId)
                IconButton(onClick = { vm.toggleLike(item.toSong()) }) {
                    Icon(
                        if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        "Like", tint = if (liked) Lilac else Ink, modifier = Modifier.size(26.dp),
                    )
                }
                DownloadButton(vm, item.toSong())
            }
        }

        Spacer(Modifier.height(4.dp))
        WaveSeek(item?.mediaId.orEmpty(), vm.positionMs, vm.durationMs, vm::seekTo)

        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().padding(bottom = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = vm::toggleShuffle) {
                Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (vm.shuffle) Lilac else Dim)
            }
            Box(
                Modifier.size(50.dp).glass(25.dp).clip(CircleShape).clickable(onClick = vm::previous),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Ink, modifier = Modifier.size(28.dp)) }
            Box(
                Modifier.size(86.dp).glass(43.dp, strong = true),
                contentAlignment = Alignment.Center,
            ) {
                if (vm.buffering) {
                    CircularProgressIndicator(Modifier.size(32.dp), color = Lilac, strokeWidth = 3.dp)
                } else {
                    PlayDot(68.dp, vm.isPlaying, vm::togglePlay)
                }
            }
            Box(
                Modifier.size(50.dp).glass(25.dp).clip(CircleShape).clickable(onClick = vm::next),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.SkipNext, "Next", tint = Ink, modifier = Modifier.size(28.dp)) }
            IconButton(onClick = vm::cycleRepeat) {
                Icon(
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repeat",
                    tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) Dim else Lilac,
                )
            }
        }
    }
}

@Composable
private fun ArtistScreen(vm: MainViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().neon().blockTouches().statusBarsPadding().navigationBarsPadding()) {
        BackRow("Artist", onBack)
        val a = vm.artist
        when {
            vm.artistLoading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                CircularProgressIndicator(color = Lilac)
            }
            a == null -> Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Text(
                    "Could not load this artist. Check your internet and try again.",
                    color = Dim, textAlign = TextAlign.Center,
                )
            }
            else -> {
                var expanded by remember(a.name) { mutableStateOf(false) }
                LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                    item {
                        Column(
                            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(
                                Modifier.size(120.dp).glass(60.dp, strong = true).padding(6.dp).clip(CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (a.avatar != null) {
                                    AsyncImage(a.avatar, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                } else {
                                    Icon(Icons.Rounded.MusicNote, null, tint = Lilac, modifier = Modifier.size(48.dp))
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    a.name, color = Ink, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                                    textAlign = TextAlign.Center,
                                )
                                if (a.verified) {
                                    Spacer(Modifier.width(6.dp))
                                    Icon(Icons.Rounded.Verified, "Verified", tint = Lilac, modifier = Modifier.size(22.dp))
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                StatCard(
                                    "Songs",
                                    if (a.hasMore) "${a.songs.size}+" else a.songs.size.toString(),
                                    Modifier.weight(1f),
                                )
                                StatCard(
                                    "Subscribers",
                                    if (a.subscribers >= 0) compact(a.subscribers) else "—",
                                    Modifier.weight(1f),
                                )
                            }
                            Spacer(Modifier.height(16.dp))
                            if (a.songs.isNotEmpty()) {
                                GlassButton("Play all") { vm.play(a.songs, 0) }
                            }
                            if (a.description != null) {
                                Spacer(Modifier.height(16.dp))
                                Text(
                                    a.description,
                                    color = Dim, fontSize = 14.sp, lineHeight = 20.sp,
                                    maxLines = if (expanded) Int.MAX_VALUE else 4,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.clickable { expanded = !expanded },
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "Songs are counted from the artist's channel.",
                                color = Dim.copy(alpha = 0.8f), fontSize = 11.sp,
                            )
                            Spacer(Modifier.height(12.dp))
                        }
                    }
                    itemsIndexed(a.songs, key = { _, s -> s.id }) { i, song ->
                        SongRow(vm, song, onArtist = null, onClick = { vm.play(a.songs, i) })
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.glass(20.dp).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = Dim, fontSize = 12.sp)
    }
}

private fun compact(n: Long): String = when {
    n >= 1_000_000_000 -> "%.1fB".format(n / 1e9)
    n >= 1_000_000 -> "%.1fM".format(n / 1e6)
    n >= 1_000 -> "%.1fK".format(n / 1e3)
    else -> n.toString()
}

private enum class Panel { NONE, LYRICS, EFFECTS }

/** Lyrics over the cover, faded back: the line being sung is big and bold. */
@Composable
private fun LyricsPanel(vm: MainViewModel, item: MediaItem) {
    LaunchedEffect(item.mediaId) { vm.loadLyrics(item) }
    val lyrics = vm.lyrics
    Box(
        Modifier.fillMaxSize().glass(28.dp).clip(RoundedCornerShape(28.dp)),
        contentAlignment = Alignment.Center,
    ) {
        item.mediaMetadata.artworkUri?.toString()?.let {
            AsyncImage(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.30f)
        }
        when {
            vm.lyricsLoading -> CircularProgressIndicator(color = Lilac)
            lyrics == null -> Text(
                "Lyrics not found for this song.",
                color = Dim, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp),
            )
            else -> {
                val tr = vm.translation
                val synced = lyrics.synced.isNotEmpty()
                val lines = if (synced) lyrics.synced.map { it.text } else lyrics.plain.orEmpty().lines()
                val state = rememberLazyListState()
                val active = if (synced) lyrics.synced.indexOfLast { it.timeMs <= vm.positionMs }.coerceAtLeast(0) else -1
                if (synced) LaunchedEffect(active) { state.animateScrollToItem(active, scrollOffset = -220) }
                LazyColumn(
                    state = state,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 20.dp, top = 56.dp, end = 20.dp, bottom = 90.dp),
                ) {
                    itemsIndexed(lines) { i, text ->
                        val on = i == active
                        Column(
                            Modifier.fillMaxWidth()
                                .let { if (synced) it.clickable { vm.seekTo(lyrics.synced[i].timeMs) } else it }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                text.ifBlank { if (synced) "♪" else " " },
                                color = if (on || !synced) Ink else Dim,
                                fontSize = if (on) 22.sp else if (synced) 18.sp else 17.sp,
                                fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            val t = tr?.getOrNull(i).orEmpty()
                            if (t.isNotBlank()) {
                                Text(
                                    t, color = Lilac,
                                    fontSize = if (on) 18.sp else 15.sp,
                                    fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth().padding(top = 3.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        // Three dots: pick the language shown under the lyrics.
        var menu by remember { mutableStateOf(false) }
        Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (vm.translating) CircularProgressIndicator(Modifier.size(18.dp), color = Lilac, strokeWidth = 2.dp)
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Rounded.MoreVert, "Lyrics language", tint = Ink)
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                LYRIC_LANGS.forEach { l ->
                    DropdownMenuItem(
                        text = { Text(l.name, color = if (vm.lyricLang == l.code) Lilac else Ink) },
                        trailingIcon = {
                            if (vm.lyricLang == l.code) Icon(Icons.Rounded.Check, null, tint = Lilac)
                        },
                        onClick = { vm.setLyricLang(l.code); menu = false },
                    )
                }
                DropdownMenuItem(
                    text = { Text("Translation off", color = if (vm.lyricLang.isEmpty()) Lilac else Dim) },
                    onClick = { vm.setLyricLang(""); menu = false },
                )
            }
        }
    }
}

@Composable
private fun EffectsPanel(vm: MainViewModel) {
    Column(
        Modifier.fillMaxSize().glass(28.dp).clip(RoundedCornerShape(28.dp))
            .verticalScroll(rememberScrollState()).padding(18.dp),
    ) {
        Text("Sound preset", color = Ink, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EffectKeys.PRESETS.forEachIndexed { i, name ->
                Chip(name, vm.fxPreset == i) { vm.setEffect(EffectKeys.PRESET, i) }
            }
        }
        Spacer(Modifier.height(18.dp))
        FxSlider("Bass boost", vm.fxBass) { vm.setEffect(EffectKeys.BASS, it) }
        FxSlider("3D surround", vm.fxVirt) { vm.setEffect(EffectKeys.VIRT, it) }
        FxSlider("Loudness", vm.fxLoud) { vm.setEffect(EffectKeys.LOUD, it) }
        Spacer(Modifier.height(6.dp))
        Text("Speed", color = Ink, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0.75f, 1f, 1.25f, 1.5f).forEach { v ->
                Chip("${v}x", vm.speed == v) { vm.setSpeed(v) }
            }
        }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.glass(50.dp, strong = selected).clip(RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(label, color = if (selected) Lilac else Ink, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FxSlider(label: String, value: Int, onChange: (Int) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Ink, fontWeight = FontWeight.Bold)
        Text("${(v / 10).toInt()}%", color = Dim)
    }
    Slider(
        value = v,
        onValueChange = { v = it },
        onValueChangeFinished = { onChange(v.toInt()) },
        valueRange = 0f..1000f,
        colors = SliderDefaults.colors(
            thumbColor = Color.White,
            activeTrackColor = Wave,
            inactiveTrackColor = Color.White.copy(alpha = 0.25f),
        ),
    )
}

private fun time(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
