package dev.cuttybeats.app

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Songs saved on the phone, inside the app's own storage (so they show up only in
 * Cutty Beats, and go away with the app). The player picks the file instead of the
 * internet whenever one exists for a song.
 */
object SongFiles {
    private const val CHUNK = 1024L * 1024
    private val http = OkHttpClient.Builder().readTimeout(30, TimeUnit.SECONDS).build()

    private fun dir(ctx: Context) = File(ctx.filesDir, "songs").apply { mkdirs() }

    fun file(ctx: Context, id: String) = File(dir(ctx), "$id.audio")

    /**
     * Saves the audio of [id]. Blocking. Read a megabyte at a time, like the player
     * does, because YouTube holds back long single requests.
     */
    fun download(ctx: Context, id: String, onProgress: (Float) -> Unit) {
        val url = YouTubeRepo.audioUrl(id)
        val part = File(dir(ctx), "$id.part")
        var pos = 0L
        var total = -1L
        try {
            part.outputStream().use { out ->
                while (total < 0 || pos < total) {
                    val req = Request.Builder().url(url)
                        .header("Range", "bytes=$pos-${pos + CHUNK - 1}").build()
                    http.newCall(req).execute().use { r ->
                        if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                        val body = r.body ?: throw IOException("Empty answer")
                        if (total < 0) {
                            total = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                                ?: body.contentLength()
                        }
                        var read = 0L
                        body.byteStream().use { input ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                read += n
                            }
                        }
                        if (read == 0L) throw IOException("No data")
                        pos += read
                        // The server ignored the range and sent everything.
                        if (r.code == 200) total = pos
                    }
                    if (total > 0) onProgress((pos.toFloat() / total).coerceAtMost(1f))
                }
            }
            if (!part.renameTo(file(ctx, id))) throw IOException("Could not save")
        } finally {
            part.delete()
        }
    }
}
