package dev.cuttybeats.app

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer

object EffectKeys {
    const val ACTION = "cutty.effect"
    const val TYPE = "type"
    const val VALUE = "value"
    const val PRESET = "preset"
    const val BASS = "bass"
    const val VIRT = "virt"
    const val LOUD = "loud"

    val PRESETS = listOf("Normal", "Bass", "Rock", "Pop", "Vocal")

    /** Band shape per preset, -1..1 from the lowest band to the highest. */
    val SHAPES = listOf(
        floatArrayOf(0f, 0f, 0f, 0f, 0f),
        floatArrayOf(1f, 0.6f, 0f, -0.2f, -0.2f),
        floatArrayOf(0.6f, 0.3f, -0.3f, 0.3f, 0.6f),
        floatArrayOf(-0.2f, 0.3f, 0.5f, 0.3f, -0.2f),
        floatArrayOf(-0.4f, 0f, 0.6f, 0.5f, 0f),
    )
}

/** Audio effects on the player's audio session. Created and driven by PlaybackService. */
class Effects {
    private var sessionId = 0
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null

    private var preset = 0
    private var bassValue = 0
    private var virtValue = 0
    private var loudValue = 0

    fun attach(id: Int) {
        if (id == sessionId && eq != null) return
        release()
        sessionId = id
        if (id == 0) return
        eq = runCatching { Equalizer(0, id).apply { enabled = true } }.getOrNull()
        bass = runCatching { BassBoost(0, id).apply { enabled = true } }.getOrNull()
        virt = runCatching { Virtualizer(0, id).apply { enabled = true } }.getOrNull()
        loud = runCatching { LoudnessEnhancer(id).apply { enabled = true } }.getOrNull()
        reapply()
    }

    fun set(type: String, value: Int) {
        when (type) {
            EffectKeys.PRESET -> preset = value
            EffectKeys.BASS -> bassValue = value
            EffectKeys.VIRT -> virtValue = value
            EffectKeys.LOUD -> loudValue = value
        }
        reapply()
    }

    private fun reapply() {
        runCatching {
            eq?.let { e ->
                val shape = EffectKeys.SHAPES.getOrElse(preset) { EffectKeys.SHAPES[0] }
                val bands = e.numberOfBands.toInt()
                val min = e.bandLevelRange[0].toInt()
                val max = e.bandLevelRange[1].toInt()
                for (b in 0 until bands) {
                    val pos = if (bands <= 1) 0f else b * (shape.size - 1f) / (bands - 1f)
                    val lo = pos.toInt().coerceIn(0, shape.size - 1)
                    val hi = (lo + 1).coerceAtMost(shape.size - 1)
                    val f = shape[lo] + (shape[hi] - shape[lo]) * (pos - lo)
                    val level = if (f >= 0) f * max else f * -min
                    e.setBandLevel(b.toShort(), (level * 0.8f).toInt().coerceIn(min, max).toShort())
                }
            }
        }
        runCatching { bass?.takeIf { it.strengthSupported }?.setStrength(bassValue.toShort()) }
        runCatching { virt?.takeIf { it.strengthSupported }?.setStrength(virtValue.toShort()) }
        runCatching { loud?.setTargetGain(loudValue) }
    }

    fun release() {
        runCatching { eq?.release() }
        runCatching { bass?.release() }
        runCatching { virt?.release() }
        runCatching { loud?.release() }
        eq = null; bass = null; virt = null; loud = null
        sessionId = 0
    }
}
