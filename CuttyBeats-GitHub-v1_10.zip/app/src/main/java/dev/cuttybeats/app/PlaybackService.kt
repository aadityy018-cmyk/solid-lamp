package dev.cuttybeats.app

import android.net.Uri
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.IOException

/**
 * Keeps the music playing in the background, with the notification and lock-screen
 * controls. Songs are queued as `cutty://yt/<videoId>` and turned into a real audio
 * address only when ExoPlayer is about to read them.
 */
@UnstableApi
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private val effects = Effects()

    override fun onCreate() {
        super.onCreate()
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val dataSources = ResolvingDataSource.Factory(
            ChunkedDataSource.Factory(DefaultDataSource.Factory(this, http)),
        ) { spec: DataSpec ->
            if (spec.uri.scheme == SCHEME) {
                val id = spec.uri.lastPathSegment ?: throw IOException("Bad song address")
                val saved = SongFiles.file(this, id)
                if (saved.exists()) {
                    // Downloaded: play from the phone, no internet needed.
                    spec.withUri(Uri.fromFile(saved))
                } else {
                    try {
                        spec.withUri(Uri.parse(YouTubeRepo.audioUrl(id)))
                    } catch (e: Exception) {
                        YouTubeRepo.forget(id)
                        throw IOException("Could not load this song: ${e.message}", e)
                    }
                }
            } else {
                spec
            }
        }

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSources))
            .setLoadControl(
                DefaultLoadControl.Builder()
                    // Start after ~0.3s of audio instead of 2.5s; keep a big buffer after.
                    .setBufferDurationsMs(20_000, 60_000, 300, 1_500)
                    .setPrioritizeTimeOverSizeThresholds(true)
                    .build(),
            )
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        // The sound effects follow the player's audio session, which can change.
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                effects.attach(audioSessionId)
            }
        })
        effects.attach(player.audioSessionId)

        session = MediaSession.Builder(this, player).setCallback(EffectCallback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Lets the app send effect settings (preset, bass, 3D, loudness) to the service. */
    private inner class EffectCallback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(EffectKeys.ACTION, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle,
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == EffectKeys.ACTION) {
                effects.set(args.getString(EffectKeys.TYPE).orEmpty(), args.getInt(EffectKeys.VALUE))
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
            }
            return super.onCustomCommand(session, controller, customCommand, args)
        }
    }

    override fun onDestroy() {
        effects.release()
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    companion object {
        const val SCHEME = "cutty"
    }
}
