package dev.cuttybeats.app

import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.stream.VideoStream
import java.util.concurrent.ConcurrentHashMap

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val thumb: String?,
    val durationSec: Long,
    /** The artist's channel, when the search told us. */
    val artistUrl: String? = null,
)

/** A video in the YouTube tab. */
data class Video(
    val id: String,
    val title: String,
    val channel: String,
    val thumb: String?,
    val durationSec: Long,
    /** Negative when YouTube does not say. */
    val views: Long = -1,
)

/** One picture quality of a video. [videoOnly] ones need the separate sound stream. */
data class VideoQuality(val label: String, val height: Int, val url: String, val videoOnly: Boolean)

data class VideoSource(val qualities: List<VideoQuality>, val audioUrl: String?)

/** Everything the artist page shows. */
data class ArtistData(
    val name: String,
    val avatar: String?,
    val description: String?,
    /** Negative when YouTube does not say. */
    val subscribers: Long,
    val verified: Boolean,
    val songs: List<Song>,
    /** True when the channel has more songs than were counted. */
    val hasMore: Boolean,
)

/**
 * The online music system, taken from the Square project: NewPipeExtractor finds
 * songs and turns a video id into a direct audio stream address. No login.
 */
object YouTubeRepo {
    private const val WATCH_URL = "https://www.youtube.com/watch?v="
    private const val TTL_MS = 60 * 60 * 1000L
    private const val MORE_PAGES = 4

    @Volatile
    private var ready = false
    private val inFlight = ConcurrentHashMap<String, java.util.concurrent.CompletableFuture<String>>()
    private val prefetchPool = java.util.concurrent.Executors.newFixedThreadPool(3)

    /** Starts NewPipe early so the first song does not wait for it. Blocking. */
    fun warmUp() = init()

    /** Resolves the audio address in the background so tapping play starts at once. */
    fun prefetch(videoId: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (streams[videoId]?.let { now - it.first < TTL_MS } == true) return
        prefetchPool.execute { runCatching { audioUrl(videoId) } }
    }
    private val streams = ConcurrentHashMap<String, Pair<Long, String>>()

    @Synchronized
    private fun init() {
        if (ready) return
        NewPipe.init(NewPipeDownloader.create(), Localization.DEFAULT)
        ready = true
    }

    /** Blocking: call from a background thread. */
    fun search(query: String): List<Song> {
        init()
        var songs = runSearch(query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS))
        if (songs.isEmpty()) songs = runSearch(query, emptyList())
        return songs
    }

    private fun runSearch(query: String, filters: List<String>): List<Song> {
        val service = ServiceList.YouTube
        val handler = service.searchQHFactory.fromQuery(query, filters, "")
        val info = SearchInfo.getInfo(service, handler)
        return info.relatedItems.toSongs()
    }

    private fun List<*>.toSongs(): List<Song> = filterIsInstance<StreamInfoItem>().mapNotNull { item ->
        val id = Regex("[?&]v=([\\w-]{11})").find(item.url)?.groupValues?.get(1)
            ?: return@mapNotNull null
        Song(
            id = id,
            title = item.name.orEmpty(),
            artist = item.uploaderName.orEmpty(),
            thumb = item.thumbnails.firstOrNull()?.url,
            durationSec = item.duration,
            artistUrl = item.uploaderUrl,
        )
    }

    /** The first channel YouTube finds for a name. */
    private fun findChannelUrl(name: String): String? {
        val service = ServiceList.YouTube
        val handler = service.searchQHFactory.fromQuery(
            name, listOf(YoutubeSearchQueryHandlerFactory.CHANNELS), "",
        )
        return SearchInfo.getInfo(service, handler).relatedItems
            .filterIsInstance<ChannelInfoItem>()
            .firstOrNull()?.url
    }

    /**
     * Who made a song: the channel's details and the songs counted on it. Blocking.
     *
     * YouTube does not give a total, so the songs are counted by reading the
     * channel's own list, a few pages deep; [ArtistData.hasMore] says it goes on.
     */
    fun artist(name: String, channelUrl: String?): ArtistData {
        init()
        val service = ServiceList.YouTube
        val url = channelUrl?.takeIf { it.isNotBlank() } ?: findChannelUrl(name)
            ?: error("No channel for $name")
        val info = ChannelInfo.getInfo(service, url)

        val songs = mutableListOf<Song>()
        var more = false
        val tab = info.tabs.firstOrNull { it.contentFilters.contains(ChannelTabs.VIDEOS) }
        if (tab != null) {
            val first = ChannelTabInfo.getInfo(service, tab)
            songs += first.relatedItems.toSongs()
            var page = first.nextPage
            var read = 0
            while (page != null && read < MORE_PAGES) {
                val next = ChannelTabInfo.getMoreItems(service, tab, page)
                songs += next.items.toSongs()
                page = next.nextPage
                read++
            }
            more = page != null
        }
        if (songs.isEmpty()) songs += search(info.name.orEmpty().ifBlank { name })

        return ArtistData(
            name = info.name.orEmpty().ifBlank { name },
            avatar = info.avatars.maxByOrNull { it.height }?.url,
            description = info.description?.takeIf { it.isNotBlank() },
            subscribers = info.subscriberCount,
            verified = info.isVerified,
            songs = songs.distinctBy { it.id },
            hasMore = more,
        )
    }

    /**
     * A direct audio address for [videoId]. Blocking. Addresses expire, so this is
     * asked for right before playing and kept for under an hour.
     *
     * AAC (M4A) first, at the best bitrate: every phone decodes it in hardware.
     */
    fun audioUrl(videoId: String): String {
        val now = android.os.SystemClock.elapsedRealtime()
        streams[videoId]?.takeIf { now - it.first < TTL_MS }?.let { return it.second }
        // One lookup per song at a time: a tap while the prefetch runs just waits for it.
        val mine = java.util.concurrent.CompletableFuture<String>()
        val running = inFlight.putIfAbsent(videoId, mine)
        if (running != null) {
            return try { running.get(30, java.util.concurrent.TimeUnit.SECONDS) }
            catch (e: java.util.concurrent.ExecutionException) { throw (e.cause as? Exception ?: e) }
        }
        try {
            val u = resolveAudio(videoId)
            streams[videoId] = android.os.SystemClock.elapsedRealtime() to u
            mine.complete(u)
            return u
        } catch (e: Exception) {
            mine.completeExceptionally(e)
            throw e
        } finally {
            inFlight.remove(videoId)
        }
    }

    private fun resolveAudio(videoId: String): String {
        init()
        val info = StreamInfo.getInfo(ServiceList.YouTube, WATCH_URL + videoId)
        val url = info.audioStreams
            .filter { !it.content.isNullOrEmpty() }
            .sortedWith(
                compareByDescending<org.schabi.newpipe.extractor.stream.AudioStream> { it.format == MediaFormat.M4A }
                    .thenByDescending { it.averageBitrate },
            )
            .firstOrNull()?.content
            ?: error("No audio stream for $videoId")
        return url
    }

    /** Videos for the YouTube tab (not only music). Blocking. */
    fun searchVideos(query: String): List<Video> {
        init()
        val service = ServiceList.YouTube
        val handler = service.searchQHFactory.fromQuery(
            query, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "",
        )
        return SearchInfo.getInfo(service, handler).relatedItems
            .filterIsInstance<StreamInfoItem>()
            .filter { it.streamType == StreamType.VIDEO_STREAM }
            .mapNotNull { item ->
                val id = Regex("[?&]v=([\\w-]{11})").find(item.url)?.groupValues?.get(1)
                    ?: return@mapNotNull null
                Video(
                    id = id,
                    title = item.name.orEmpty(),
                    channel = item.uploaderName.orEmpty(),
                    thumb = item.thumbnails.firstOrNull()?.url,
                    durationSec = item.duration,
                    views = item.viewCount,
                )
            }
            .distinctBy { it.id }
    }

    /**
     * The picture and sound addresses for watching [videoId]. Blocking.
     *
     * YouTube keeps the sharp pictures (up to 1080p) apart from the sound, so those
     * come as video-only plus [VideoSource.audioUrl]; the player plays both together.
     * Only when there is no separate sound does this fall back to the ready-made
     * pictures that already carry sound (usually 360p).
     */
    fun videoSource(videoId: String): VideoSource {
        init()
        val info = StreamInfo.getInfo(ServiceList.YouTube, WATCH_URL + videoId)
        val web = DeliveryMethod.PROGRESSIVE_HTTP
        fun heightOf(s: VideoStream) =
            Regex("(\\d+)p").find(s.resolution.orEmpty())?.groupValues?.get(1)?.toIntOrNull() ?: 0

        val audio = info.audioStreams
            .filter { !it.content.isNullOrEmpty() }
            .sortedWith(
                compareByDescending<AudioStream> { it.format == MediaFormat.M4A }
                    .thenByDescending { it.averageBitrate },
            )
            .firstOrNull()?.content

        val sharp = info.videoOnlyStreams
            .filter { it.deliveryMethod == web && !it.content.isNullOrEmpty() && it.format == MediaFormat.MPEG_4 }
        // H.264 plays in hardware on every phone; AV1 only on new ones.
        val pool = sharp.filter { it.codec.orEmpty().startsWith("avc1") }.ifEmpty { sharp }
        val adaptive: List<VideoQuality> = if (audio == null) emptyList() else pool
            .groupBy { heightOf(it) }
            .filterKeys { it >= 144 }
            .mapNotNull { (h, list) ->
                // 30 fps ("720p") before 60 fps ("720p60"): lighter on the phone.
                list.minByOrNull { it.resolution.orEmpty().length }
                    ?.let { VideoQuality("${h}p", h, it.content, videoOnly = true) }
            }

        val ready = info.videoStreams
            .filter { it.deliveryMethod == web && !it.content.isNullOrEmpty() }
            .mapNotNull { s ->
                val h = heightOf(s)
                if (h <= 0 || adaptive.any { it.height == h }) null
                else VideoQuality("${h}p", h, s.content, videoOnly = false)
            }

        val all = (adaptive + ready).sortedByDescending { it.height }
        if (all.isEmpty()) error("No video stream for $videoId")
        return VideoSource(all, audio)
    }

    fun forget(videoId: String) {
        streams.remove(videoId)
    }
}
