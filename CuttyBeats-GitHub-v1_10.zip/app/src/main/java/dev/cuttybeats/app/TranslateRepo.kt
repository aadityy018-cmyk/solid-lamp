package dev.cuttybeats.app

import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** The 10 languages offered under the lyrics. [code] "" means translation is off. */
data class LyricLang(val code: String, val name: String)

val LYRIC_LANGS = listOf(
    LyricLang("hi", "हिन्दी (Hindi)"),
    LyricLang("en", "English"),
    LyricLang("bn", "বাংলা (Bengali)"),
    LyricLang("ta", "தமிழ் (Tamil)"),
    LyricLang("te", "తెలుగు (Telugu)"),
    LyricLang("mr", "मराठी (Marathi)"),
    LyricLang("gu", "ગુજરાતી (Gujarati)"),
    LyricLang("pa", "ਪੰਜਾਬੀ (Punjabi)"),
    LyricLang("ur", "اردو (Urdu)"),
    LyricLang("kn", "ಕನ್ನಡ (Kannada)"),
)

/** Translates lyric lines with the free Google Translate web endpoint. Blocking. */
object TranslateRepo {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private val cache = ConcurrentHashMap<String, List<String>>()

    /** One translated string per input line (same order, same count). */
    fun translate(key: String, lines: List<String>, lang: String): List<String>? {
        val ck = "$key|$lang"
        cache[ck]?.let { return it }
        val idx = lines.indices.filter { lines[it].isNotBlank() }
        if (idx.isEmpty()) return null
        val src = idx.map { lines[it].replace('\n', ' ') }

        var out: List<String>? = null
        // All lines in one request (fast); lines come back split by newline.
        runCatching { request(src.joinToString("\n"), lang) }.getOrNull()?.let { joined ->
            val parts = joined.split("\n")
            if (parts.size == src.size) out = parts
        }
        // Count did not match: translate line by line, 6 at a time.
        if (out == null) {
            val result = arrayOfNulls<String>(src.size)
            src.indices.chunked(6).forEach { group ->
                val threads = group.map { i ->
                    Thread { result[i] = runCatching { request(src[i], lang) }.getOrNull() }
                        .also { it.start() }
                }
                threads.forEach { it.join() }
            }
            out = result.map { it ?: "" }
        }

        val full = MutableList(lines.size) { "" }
        idx.forEachIndexed { n, i -> full[i] = out!![n].trim() }
        cache[ck] = full
        return full
    }

    private fun request(text: String, lang: String): String {
        val url = "https://translate.googleapis.com/translate_a/single" +
            "?client=gtx&sl=auto&tl=$lang&dt=t"
        val body = FormBody.Builder().add("q", text).build()
        val req = Request.Builder().url(url).post(body)
            .header("User-Agent", "Mozilla/5.0 (Android) CuttyBeats").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("translate ${r.code}")
            val root = JSONArray(r.body?.string() ?: error("empty"))
            val segs = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segs.length()) {
                val s = segs.optJSONArray(i) ?: continue
                sb.append(s.optString(0, ""))
            }
            return sb.toString()
        }
    }
}
