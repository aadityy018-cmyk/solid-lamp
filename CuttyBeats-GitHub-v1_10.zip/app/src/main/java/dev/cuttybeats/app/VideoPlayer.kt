package dev.cuttybeats.app

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The player behind the YouTube tab.
 *
 * It is a second ExoPlayer, separate from the music one in [PlaybackService]: the
 * picture only lives while the app is on screen, the music keeps going in the
 * background. The two never play together (see MainViewModel.watch and sync).
 */
@UnstableApi
class VideoHolder(
    private val context: Context,
    private val scope: CoroutineScope,
) {
    private var exo: ExoPlayer? = null

    /** Made on first use, so the app starts no slower for people who never open the tab. */
    val player: ExoPlayer
        get() = exo ?: build().also { exo = it }

    var video by mutableStateOf<Video?>(null)
        private set
    var qualities by mutableStateOf<List<VideoQuality>>(emptyList())
        private set
    var quality by mutableStateOf<VideoQuality?>(null)
        private set
    /** True while the addresses are being looked up. */
    var loading by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var fullscreen by mutableStateOf(false)

    private var audioUrl: String? = null
    private var retried = false

    private val sources by lazy {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        // Same piece-by-piece reading as the music, so YouTube does not hold it back.
        ProgressiveMediaSource.Factory(
            ChunkedDataSource.Factory(DefaultDataSource.Factory(context, http)),
        )
    }

    private fun build(): ExoPlayer = ExoPlayer.Builder(context)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            /* handleAudioFocus = */ true,
        )
        .setHandleAudioBecomingNoisy(true)
        .build()
        .also { p ->
            p.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    buffering = state == Player.STATE_BUFFERING
                }

                override fun onPlayerError(error: PlaybackException) {
                    val v = video ?: return
                    // Addresses run out after a while: look them up again once, and go on.
                    if (!retried) {
                        retried = true
                        play(v, p.currentPosition, user = false)
                    } else {
                        loading = false
                        toast("Could not play this video. Try another one.")
                    }
                }
            })
        }

    /** Looks the video up and starts it. [user] is false for the automatic retry. */
    fun play(v: Video, startMs: Long = 0L, user: Boolean = true) {
        if (user) retried = false
        video = v
        loading = true
        scope.launch {
            try {
                val src = withContext(Dispatchers.IO) { YouTubeRepo.videoSource(v.id) }
                if (video?.id != v.id) return@launch // another video was picked meanwhile
                audioUrl = src.audioUrl
                qualities = src.qualities
                // Sharp but light: 720p, or the best one below it.
                val keep = quality?.takeIf { !user }?.let { q -> src.qualities.firstOrNull { it.height == q.height } }
                val pick = keep
                    ?: src.qualities.firstOrNull { it.height in 1..720 }
                    ?: src.qualities.last()
                quality = pick
                load(pick, startMs)
            } catch (e: Exception) {
                if (video?.id == v.id) toast("Could not load this video. Check your internet.")
            } finally {
                if (video?.id == v.id) loading = false
            }
        }
    }

    /** Another picture quality, from the same second. */
    fun setQuality(q: VideoQuality) {
        if (q == quality) return
        val at = exo?.currentPosition ?: 0L
        quality = q
        load(q, at)
    }

    private fun load(q: VideoQuality, startMs: Long) {
        val picture = sources.createMediaSource(MediaItem.fromUri(q.url))
        val audio = audioUrl
        val source: MediaSource = if (q.videoOnly && audio != null) {
            MergingMediaSource(picture, sources.createMediaSource(MediaItem.fromUri(audio)))
        } else {
            picture
        }
        player.run {
            setMediaSource(source, startMs)
            prepare()
            playWhenReady = true
        }
    }

    fun pause() {
        exo?.pause()
    }

    val isPlaying: Boolean get() = exo?.isPlaying == true

    fun release() {
        exo?.release()
        exo = null
    }

    private fun toast(text: String) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
    }
}
